# The University of Law

### Developer Technical Test

***
Create a repo from this template repo.

Then read the word document which has the instructions for the test.
***

#### To Submit the test.
Submit a link to your new repo which is preferably public.

If the repo is private then you will be given instructions on who to invite to be able to clone the repo.

Do the test and please commit frequently as we want to see your thought processes in solving the test.

This should take about an hour. 
If there are things you think should be done but you dont have time then make comments in your code. 

Good comments are as valid as code.

***
## Good Luck
