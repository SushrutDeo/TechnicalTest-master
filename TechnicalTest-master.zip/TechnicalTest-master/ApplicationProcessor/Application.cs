﻿using System;
using System.Text;

using Ulaw.ApplicationProcessor;

using ULaw.ApplicationProcessor.Enums;

namespace ULaw.ApplicationProcessor
{
	// Removed ApplicationId as it's not being used anywhere but if someone wants to assign unique id when the application is made
	// we can generate it
	public class Application : IApplication
	{
		// The constructor shouldn't receive those many parameters but instances of the relevant classes
		public Application( string faculty, string courseCode, DateTime startdate, string title, string firstName, string lastName,
			DateTime dateOfBirth, bool requiresVisa )
		{
			// Ideally this should be injected
			Course course = new Course( faculty, courseCode, startdate );

			Course = course;

			// Ideally this should be injected
			Student student = new Student( title, firstName, lastName, dateOfBirth, requiresVisa );

			Student = student;
		}

		public DegreeGradeEnum DegreeGrade { get; set; }

		public DegreeSubjectEnum DegreeSubject { get; set; }

		public Course Course { get; set; }

		public Student Student { get; set; }

		public string Process()
		{
			var result = new StringBuilder( "<html><body><h1>Your Recent Application from the University of Law</h1>" );

			switch ( DegreeGrade )
			{
				case DegreeGradeEnum.first:
				case DegreeGradeEnum.twoOne:

					switch ( DegreeSubject )
					{
						case DegreeSubjectEnum.law:
						case DegreeSubjectEnum.lawAndBusiness:

							decimal depositAmount = 350.00M;

							result.Append( string.Format( "<p> Dear {0}, </p>", Student.FirstName ) );
							result.Append( string.Format( "<p/> Further to your recent application, we are delighted to offer you a place on our course reference: {0} starting on {1}.", Course.CourseCode, Course.StartDate.ToLongDateString() ) );
							result.Append( string.Format( "<br/> This offer will be subject to evidence of your qualifying {0} degree at grade: {1}.", DegreeSubject.ToDescription(), DegreeGrade.ToDescription() ) );
							result.Append( string.Format( "<br/> Please contact us as soon as possible to confirm your acceptance of your place and arrange payment of the £{0} deposit fee to secure your place.", depositAmount.ToString() ) );
							result.Append( string.Format( "<br/> We look forward to welcoming you to the University," ) );
							result.Append( string.Format( "<br/> Yours sincerely," ) );
							result.Append( string.Format( "<p/> The Admissions Team," ) );

							break;

						case DegreeSubjectEnum.maths:
						case DegreeSubjectEnum.English:

							result.Append( string.Format( "<p> Dear {0}, </p>", Student.FirstName ) );
							result.Append( string.Format( "<p/> Further to your recent application for our course reference: {0} starting on {1}, we are writing to inform you that we are currently assessing your information and will be in touch shortly.", Course.CourseCode, Course.StartDate.ToLongDateString() ) );
							result.Append( "<br/> If you wish to discuss any aspect of your application, please contact us at AdmissionsTeam@Ulaw.co.uk." );
							result.Append( "<br/> Yours sincerely," );
							result.Append( "<p/> The Admissions Team," );

							break;

						default:

							// Do something here to handle error

							break;
					}

					break;

				case DegreeGradeEnum.twoTwo:

					result.Append( string.Format( "<p> Dear {0}, </p>", Student.FirstName ) );
					result.Append( string.Format( "<p/> Further to your recent application for our course reference: {0} starting on {1}, we are writing to inform you that we are currently assessing your information and will be in touch shortly.", Course.CourseCode, Course.StartDate.ToLongDateString() ) );
					result.Append( "<br/> If you wish to discuss any aspect of your application, please contact us at AdmissionsTeam@Ulaw.co.uk." );
					result.Append( "<br/> Yours sincerely," );
					result.Append( "<p/> The Admissions Team," );

					break;

				case DegreeGradeEnum.third:

					result.Append( string.Format( "<p> Dear {0}, </p>", Student.FirstName ) );
					result.Append( "<p/> Further to your recent application, we are sorry to inform you that you have not been successful on this occasion." );
					result.Append( "<br/> If you wish to discuss the decision further, or discuss the possibility of applying for an alternative course with us, please contact us at AdmissionsTeam@Ulaw.co.uk." );
					result.Append( "<br> Yours sincerely," );
					result.Append( "<p/> The Admissions Team," );

					break;

				default:

					// Do something here to handle error

					break;
			}

			result.Append( string.Format( "</body></html>" ) );

			return result.ToString();
		}
	}
}

