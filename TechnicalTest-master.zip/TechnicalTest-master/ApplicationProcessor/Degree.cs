﻿using ULaw.ApplicationProcessor.Enums;

namespace Ulaw.ApplicationProcessor
{
	/// <summary>
	/// Ideally this class should go into the 'Models' project but keeping it here for the sake of simplicity.
	/// Cuurently we are not able to use this class as I am not allowed to change the tests but this should exist.
	/// </summary>
	public class Degree
	{
		public string Name { get; private set; }

		public DegreeGradeEnum DegreeGrade { get; set; }

		public DegreeSubjectEnum DegreeSubject { get; set; }
	}
}
