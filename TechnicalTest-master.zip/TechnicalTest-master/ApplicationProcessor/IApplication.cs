﻿
using Ulaw.ApplicationProcessor;

using ULaw.ApplicationProcessor.Enums;

namespace ULaw.ApplicationProcessor
{
	public interface IApplication
	{
		Course Course { get; set; }

		Student Student { get; set; }

		DegreeGradeEnum DegreeGrade { get; set; }

		DegreeSubjectEnum DegreeSubject { get; set; }

		string Process();
	}
}