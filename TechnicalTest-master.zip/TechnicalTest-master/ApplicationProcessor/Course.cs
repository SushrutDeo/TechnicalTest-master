﻿using System;

namespace Ulaw.ApplicationProcessor
{
	/// <summary>
	/// Ideally this class should go into the 'Models' project but keeping it here for the sake of simplicity.
	/// </summary>
	public class Course
	{
		public Course( string faculty, string courseCode, DateTime startDate )
		{
			Faculty = faculty; // Ideally there should be another class called 'Faculty' and 'Course' and 'Faculty' should be 
							   // connected using 1 to M relationship. 1 faculty can teach many courses unless for a given
							   //university one course can be taught by many faculties. In that case we need M to M relationship

			CourseCode = courseCode;
			StartDate = startDate;
		}

		// Currently we are not using this but it should be used in the ideal scenario
		public string Name { get; set; }

		public string Faculty { get; private set; }

		public string CourseCode { get; private set; }

		public DateTime StartDate { get; private set; }
	}
}
